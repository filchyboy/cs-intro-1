"""
Hello, World!
"""
# 1. Print a string
print("This line will be printed.")

# 2. Indentation for blocks (four spaces)
x = 1
if x == 1: 
    # indented four spaces
    print("x is 1.")
