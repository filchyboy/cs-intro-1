# Guided Project - Starter: Introduction to Python I

All of the starter files are located inside [src](src). These files will be helpful as you follow along with the Guided Project. Use the files on your local machine in your preferred editor as you follow along.
